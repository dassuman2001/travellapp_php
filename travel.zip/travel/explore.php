<?php
session_start();
include_once "db_connection.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$location = $_GET['location'];
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Explore <?php echo $location; ?></title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            padding-top: 56px; /* Account for fixed navbar height */
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 1rem;
        }
        .company-name {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .menu {
            float: right;
        }
        .menu a {
            color: #fff;
            text-decoration: none;
            margin-left: 1rem;
        }
        main {
            padding: 2rem;
        }
        h1 {
            margin-bottom: 1.5rem;
        }
        form {
            margin-bottom: 2rem;
        }
        form h3 {
            margin-bottom: 1rem;
        }
        input[type="text"],
        input[type="date"],
        select,
        input[type="submit"] {
            padding: 0.5rem 1rem;
            margin-bottom: 1rem;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 1rem;
        }
        input[type="submit"] {
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #0056b3;
        }
        footer {
            background-color: #f8f9fa;
            text-align: center;
            padding: 1rem;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>
    <header>
        <div class="company-name">TravelApp</div>
        <div class="menu">
            <a href="dashboard.php">Account</a>
            <a href="logout.php">Logout</a>
        </div>
    </header>

    <main>
        <h1>Explore <?php echo $location; ?></h1>

        <!-- Flight Booking Form -->
        <form action="book_flight.php" method="POST">
            <h3>Book a Flight</h3>
            <input type="hidden" name="destination_city" value="<?php echo $location; ?>">
            <input type="text" name="departure_city" placeholder="Departure City" required>
            <input type="date" name="departure_date" required>
            <input type="submit" value="Book Flight">
        </form>

        <!-- Hotel Booking Form -->
        <form action="book_hotel.php" method="POST">
            <h3>Book a Hotel</h3>
            <input type="hidden" name="location" value="<?php echo $location; ?>">
            <select name="hotel_name" required>
                <?php
                $hotels = [
                    "UK" => ["Hotel A", "Hotel B", "Hotel C", "Hotel D", "Hotel E"],
                    "US" => ["Hotel F", "Hotel G", "Hotel H", "Hotel I", "Hotel J"],
                    "Australia" => ["Hotel K", "Hotel L", "Hotel M", "Hotel N", "Hotel O"],
                    "Dubai" => ["Hotel P", "Hotel Q", "Hotel R", "Hotel S", "Hotel T"],
                    "India" => ["Hotel U", "Hotel V", "Hotel W", "Hotel X", "Hotel Y"],
                    "Russia" => ["Hotel Z", "Hotel AA", "Hotel AB", "Hotel AC", "Hotel AD"],
                    "Kolkata" => ["Hotel AE", "Hotel AF", "Hotel AG", "Hotel AH", "Hotel AI"],
                    "France" => ["Hotel AJ", "Hotel AK", "Hotel AL", "Hotel AM", "Hotel AN"],
                    "Italy" => ["Hotel AO", "Hotel AP", "Hotel AQ", "Hotel AR", "Hotel AS"]
                ];

                foreach ($hotels[$location] as $hotel): ?>
                    <option value="<?php echo $hotel; ?>"><?php echo $hotel; ?></option>
                <?php endforeach; ?>
            </select>
            <input type="date" name="check_in_date" required>
            <input type="date" name="check_out_date" required>
            <input type="submit" value="Book Hotel">
        </form>
    </main>

    <footer>
        <p>&copy; 2024 TravelApp. All rights reserved.</p>
    </footer>
</body>
</html>
