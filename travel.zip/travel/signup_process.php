<?php
// Include database connection file
include_once "db_connection.php";

// Get form data
$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password'];

// Hash the password
$hashed_password = password_hash($password, PASSWORD_DEFAULT);

// Insert user data into database
$query = "INSERT INTO users (username, email, password) VALUES ('$username', '$email', '$hashed_password')";
$result = mysqli_query($conn, $query);

if ($result) {
    // Registration successful
    header("Location: login.php"); // Redirect to login page
    exit();
} else {
    // Registration failed
    echo "Error: " . $query . "<br>" . mysqli_error($conn);
}

// Close database connection
mysqli_close($conn);
?>
