<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Home - TravelApp</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            padding-top: 56px; /* Account for fixed navbar height */
        }
        .navbar {
            background-color: #f8f9fa;
            padding: 1rem;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            top: 0;
            z-index: 1000;
        }
        .navbar .company-name {
            font-size: 1.5rem;
            font-weight: bold;
        }
        .navbar .menu {
            float: right;
        }
        .navbar .menu a {
            margin-left: 1rem;
            text-decoration: none;
            color: #333;
        }
        .navbar .menu a:hover {
            color: #007bff;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 2rem;
        }
        .text-center {
            text-align: center;
        }
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: -1rem;
        }
        .col-md-4 {
            flex: 0 0 33.333%; /* Change flex property to occupy one-third of the container's width */
            max-width: 33.333%;
            padding: 1rem;
            box-sizing: border-box;
        }
        .card {
            border: 1px solid #ddd;
            border-radius: 4px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease-in-out; /* Added for card hover effect */
        }
        .card:hover {
            transform: scale(1.05); /* Card zoom effect */
        }
        .card-img-top {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.3s ease-in-out; /* Added for image hover effect */
        }
        .card-img-top:hover {
            transform: scale(1.1); /* Image zoom effect */
        }
        .card-body {
            padding: 1rem;
        }
        .card-title {
            font-size: 1.25rem;
            margin-bottom: 0.5rem;
        }
        .card-text {
            margin-bottom: 1rem;
            color: #555;
        }
        .btn-primary {
            display: inline-block;
            padding: 0.5rem 1rem;
            color: #fff;
            background-color: #007bff;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            font-size: 1rem;
        }
        .btn-primary:hover {
            background-color: #0056b3;
        }
        footer {
            background-color: #f8f9fa;
            text-align: center;
            padding: 1rem;
            box-shadow: 0 -4px 6px rgba(0, 0, 0, 0.1);
            position: fixed;
            width: 100%;
            bottom: 0;
        }
    </style>
</head>
<body>
    <header>
        <nav class="navbar">
            <div class="company-name">TravelApp</div>
            <div class="menu">
                <?php if (isset($_SESSION['user_id'])): ?>
                    <a href="dashboard.php">Account</a>
                    <a href="logout.php">Logout</a>
                <?php else: ?>
                    <a href="signup.php">Signup</a>
                    <a href="login.php">Login</a>
                <?php endif; ?>
            </div>
        </nav>
    </header>

    <main class="container mt-4">
        <h1 class="text-center">Explore Destinations</h1>
        <div id="destinations" class="row">
            <?php
            $locations = [
                "India" => "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?q=80&w=2071&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "UK" => "https://images.unsplash.com/photo-1562767332-ce0b1e2426bb?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "Kolkata" => "https://images.unsplash.com/photo-1571679654681-ba01b9e1e117?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "US" => "https://images.unsplash.com/photo-1551021456-c8b810eed320?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "Australia" => "https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "Dubai" => "https://images.unsplash.com/photo-1580674684081-7617fbf3d745?q=80&w=1974&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "Russia" => "https://images.unsplash.com/photo-1547448415-e9f5b28e570d?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "France" => "https://images.unsplash.com/photo-1431274172761-fca41d930114?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D",
                "Italy" => "https://images.unsplash.com/photo-1520175480921-4edfa2983e0f?q=80&w=2067&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
            ];
            foreach ($locations as $location => $image): ?>
                <div class="col-md-4 mb-4">
                    <div class="card">
                        <img src="<?php echo $image; ?>" class="card-img-top" alt="<?php echo $location; ?>">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo $location; ?></h5>
                            <p class="card-text">Discover the beauty and attractions of <?php echo $location; ?>.</p>
                            <a href="explore.php?location=<?php echo urlencode($location); ?>" class="btn btn-primary">Explore</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </main>

    <footer>
        <p>&copy; 2024 TravelApp. All rights reserved.</p>
    </footer>
</body>
</html>
