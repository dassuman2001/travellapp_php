<?php
session_start();
include_once "db_connection.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_SESSION['user_id'];
    $departure_city = $_POST['departure_city'];
    $destination_city = $_POST['destination_city'];
    $departure_date = $_POST['departure_date'];
    $booking_date = date("Y-m-d");

    $query = "INSERT INTO flight_bookings (user_id, departure_city, destination_city, departure_date, booking_date) VALUES ('$user_id', '$departure_city', '$destination_city', '$departure_date', '$booking_date')";
    if (mysqli_query($conn, $query)) {
        header("Location: dashboard.php");
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
mysqli_close($conn);
?>
