<?php
// Include database connection file
include_once "db_connection.php";

// Start session
session_start();

// Get form data
$email = $_POST['email'];
$password = $_POST['password'];

// Retrieve user data from database
$query = "SELECT * FROM users WHERE email='$email'";
$result = mysqli_query($conn, $query);
$user = mysqli_fetch_assoc($result);

if ($user && password_verify($password, $user['password'])) {
    // Login successful
    $_SESSION['user_id'] = $user['user_id']; // Store user ID in session
    $_SESSION['username'] = $user['username']; // Store username in session
    header("Location: dashboard.php"); // Redirect to dashboard
    exit();
} else {
    // Login failed
    echo "Invalid email or password.";
}

// Close database connection
mysqli_close($conn);
?>
