<?php
session_start();
include_once "db_connection.php";

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Fetch flight booking history
$flight_query = "SELECT * FROM flight_bookings WHERE user_id = '$user_id' ORDER BY booking_date DESC";
$flight_result = mysqli_query($conn, $flight_query);

// Fetch hotel booking history
$hotel_query = "SELECT * FROM hotel_bookings WHERE user_id = '$user_id' ORDER BY booking_date DESC";
$hotel_result = mysqli_query($conn, $hotel_query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <nav>
            <div class="company-name">TravelApp</div>
            <div class="menu">
                <a href="logout.php">Logout</a>
            </div>
        </nav>
    </header>

    <main>
        <h1>Welcome, <?php echo $_SESSION['username']; ?>!</h1>

        <!-- Display Flight Booking History -->
        <h3>Your Flight Booking Activities:</h3>
        <ul>
            <?php
            if (mysqli_num_rows($flight_result) > 0) {
                while ($flight = mysqli_fetch_assoc($flight_result)) {
                    echo "<li>From: " . $flight['departure_city'] . " To: " . $flight['destination_city'] . " on " . $flight['departure_date'] . " (Booked on: " . $flight['booking_date'] . ")</li>";
                }
            } else {
                echo "<li>No flight bookings found.</li>";
            }
            ?>
        </ul>

        <!-- Display Hotel Booking History -->
        <h3>Your Hotel Booking Activities:</h3>
        <ul>
            <?php
            if (mysqli_num_rows($hotel_result) > 0) {
                while ($hotel = mysqli_fetch_assoc($hotel_result)) {
                    echo "<li>Hotel: " . $hotel['hotel_name'] . " in " . $hotel['location'] . " from " . $hotel['check_in_date'] . " to " . $hotel['check_out_date'] . " (Booked on: " . $hotel['booking_date'] . ")</li>";
                }
            } else {
                echo "<li>No hotel bookings found.</li>";
            }
            ?>
        </ul>
    </main>

    <footer>
        <p>&copy; 2024 TravelApp. All rights reserved.</p>
    </footer>

    <?php
    mysqli_close($conn);
    ?>
</body>
</html>
