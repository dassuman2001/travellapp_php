// Sample data for featured locations
const locations = [
    { 
        name: "UK",
        description: "United Kingdom - Explore the historic landmarks of London and the beautiful countryside.",
        image: "https://images.unsplash.com/photo-1562767332-ce0b1e2426bb?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    { 
        name: "US",
        description: "United States - Discover the vibrant cities, stunning national parks, and diverse culture.",
        image: "https://images.unsplash.com/photo-1562767332-ce0b1e2426bb?q=80&w=2070&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D"
    },
    { 
        name: "Australia",
        description: "Australia - Experience the unique wildlife, stunning beaches, and outback adventures.",
        image: "images/australia.jpg"
    },
    { 
        name: "Dubai",
        description: "Dubai - Explore the futuristic cityscape, luxurious resorts, and desert safaris.",
        image: "images/dubai.jpg"
    },
    { 
        name: "India",
        description: "India - Immerse yourself in the rich culture, ancient temples, and bustling streets.",
        image: "images/india.jpg"
    },
    { 
        name: "Russia",
        description: "Russia - Discover the grandeur of Moscow, the beauty of St. Petersburg, and the vast wilderness of Siberia.",
        image: "images/russia.jpg"
    },
    { 
        name: "Kolkata",
        description: "Kolkata - Experience the cultural capital of India with its historic architecture, vibrant festivals, and delicious cuisine.",
        image: "images/kolkata.jpg"
    },
    { 
        name: "France",
        description: "France - Indulge in gourmet cuisine, explore romantic cities, and visit iconic landmarks like the Eiffel Tower.",
        image: "images/france.jpg"
    },
    { 
        name: "Italy",
        description: "Italy - Delight in art, history, and cuisine in cities like Rome, Florence, and Venice.",
        image: "images/italy.jpg"
    }
    // Add more locations here
];

// Function to populate featured locations
function populateLocations() {
    const locationsContainer = document.getElementById("locations");
    locations.forEach(location => {
        const locationElement = document.createElement("div");
        locationElement.classList.add("location");
        locationElement.innerHTML = `
            <img src="${location.image}" alt="${location.name}">
            <h2>${location.name}</h2>
            <p>${location.description}</p>
            <button onclick="exploreLocation('${location.name}')">Explore</button>
        `;
        locationsContainer.appendChild(locationElement);
    });
}

// Function to explore a location
function exploreLocation(locationName) {
    // Redirect to the individual location page for further exploration
    window.location.href = `location.php?name=${locationName}`;
}

// Populate featured locations on page load
populateLocations();

// Function to book a flight for the selected location
function bookFlight(locationName) {
    // Implement booking logic here
    alert(`Booking flight for ${locationName}`);
}

// Function to book a hotel for the selected location
function bookHotel(locationName) {
    // Implement booking logic here
    alert(`Booking hotel for ${locationName}`);
}
