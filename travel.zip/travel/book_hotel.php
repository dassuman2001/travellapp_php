<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();
include_once "db_connection.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_SESSION['user_id']) && isset($_POST['location']) && isset($_POST['hotel_name']) && isset($_POST['check_in_date']) && isset($_POST['check_out_date'])) {
        $user_id = $_SESSION['user_id'];
        $location = $_POST['location'];
        $hotel_name = $_POST['hotel_name'];
        $check_in_date = $_POST['check_in_date'];
        $check_out_date = $_POST['check_out_date'];
        $booking_date = date("Y-m-d");

        $query = "INSERT INTO hotel_bookings (user_id, location, hotel_name, check_in_date, check_out_date, booking_date) VALUES ('$user_id', '$location', '$hotel_name', '$check_in_date', '$check_out_date', '$booking_date')";
        if (mysqli_query($conn, $query)) {
            header("Location: dashboard.php");
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
    } else {
        echo "Required fields are missing.";
    }
}
mysqli_close($conn);
?>
